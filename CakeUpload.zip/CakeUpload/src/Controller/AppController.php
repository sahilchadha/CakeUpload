<?php

namespace CakeUpload\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{

}
